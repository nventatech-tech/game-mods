// Options shown in the Mod Settings menu. Mod Settings is optional: without it the defaults apply.
module FindMyRide

public class FindMyRideSettings extends ScriptableSystem {

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-RememberCategory")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-RememberCategory-Desc")
  public let rememberCategory: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-HideBeta")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-HideBeta-Desc")
  public let hideBetaWarning: Bool = true;

  public static func Get(game: GameInstance) -> ref<FindMyRideSettings> {
    return GameInstance.GetScriptableSystemsContainer(game).Get(n"FindMyRide.FindMyRideSettings") as FindMyRideSettings;
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {}

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.UnregisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {}
}
