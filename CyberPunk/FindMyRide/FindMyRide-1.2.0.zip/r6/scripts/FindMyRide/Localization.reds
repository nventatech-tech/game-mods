// Translations for FindMyRide. Add a package + a case in GetPackage to support a new language.
module FindMyRide.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-FindMyRide-Cat-All", "All");
    this.Text("Mod-FindMyRide-Cat-Favorites", "Favorites");
    this.Text("Mod-FindMyRide-Cat-Cars", "Cars");
    this.Text("Mod-FindMyRide-Cat-Motorcycles", "Motorcycles");
    this.Text("Mod-FindMyRide-Cat-Armed", "Armed");
    this.Text("Mod-FindMyRide-Bar-SearchPrefix", "Search: ");
    this.Text("Mod-FindMyRide-Bar-SearchHint", "confirm   [Esc] clear");
    this.Text("Mod-FindMyRide-Bar-Search", "search");
    this.Text("Mod-FindMyRide-Bar-Clear", "clear");
    this.Text("Mod-FindMyRide-Title", "Find My Ride");
    this.Text("Mod-FindMyRide-Set-RememberCategory", "Remember category");
    this.Text("Mod-FindMyRide-Set-RememberCategory-Desc", "Reopen the vehicle list on the last category used. Off means it always opens on All.");
    this.Text("Mod-FindMyRide-Set-HideBeta", "Hide Beta warning");
    this.Text("Mod-FindMyRide-Set-HideBeta-Desc", "Hide the vanilla \"vehicle delivery is still in Beta\" disclaimer to free up screen space.");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-FindMyRide-Cat-All", "Todos");
    this.Text("Mod-FindMyRide-Cat-Favorites", "Favoritos");
    this.Text("Mod-FindMyRide-Cat-Cars", "Carros");
    this.Text("Mod-FindMyRide-Cat-Motorcycles", "Motos");
    this.Text("Mod-FindMyRide-Cat-Armed", "Armados");
    this.Text("Mod-FindMyRide-Bar-SearchPrefix", "Busca: ");
    this.Text("Mod-FindMyRide-Bar-SearchHint", "confirmar   [Esc] limpar");
    this.Text("Mod-FindMyRide-Bar-Search", "buscar");
    this.Text("Mod-FindMyRide-Bar-Clear", "limpar");
    this.Text("Mod-FindMyRide-Title", "Find My Ride");
    this.Text("Mod-FindMyRide-Set-RememberCategory", "Lembrar categoria");
    this.Text("Mod-FindMyRide-Set-RememberCategory-Desc", "Reabre a lista de veículos na última categoria usada. Desligado, abre sempre em Todos.");
    this.Text("Mod-FindMyRide-Set-HideBeta", "Ocultar aviso de Beta");
    this.Text("Mod-FindMyRide-Set-HideBeta-Desc", "Esconde o aviso original de que a entrega de veículos ainda está em Beta, liberando espaço na tela.");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
