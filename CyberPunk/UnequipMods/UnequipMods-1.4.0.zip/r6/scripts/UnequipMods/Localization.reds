// Translations for UnequipMods. Add a package + a case in GetPackage to support a new language.
module UnequipMods.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-UnequipMods-Returned", "Mods returned to inventory");
    this.Text("Mod-UnequipMods-Title", "Unequip Mods");
    this.Text("Mod-UnequipMods-Set-Sell", "Strip mods when selling");
    this.Text("Mod-UnequipMods-Set-Sell-Desc", "Mods return to your inventory before an item is sold, including bulk sell and drop points.");
    this.Text("Mod-UnequipMods-Set-Disassemble", "Strip mods when disassembling");
    this.Text("Mod-UnequipMods-Set-Disassemble-Desc", "Mods return to your inventory before an item is disassembled.");
    this.Text("Mod-UnequipMods-Set-Drop", "Strip mods when dropping");
    this.Text("Mod-UnequipMods-Set-Drop-Desc", "Mods return to your inventory before an item is dropped on the ground.");
    this.Text("Mod-UnequipMods-Set-Toast", "Show notification");
    this.Text("Mod-UnequipMods-Set-Toast-Desc", "On-screen message with the count of returned mods.");
    this.Text("Mod-UnequipMods-Set-Cleanup", "Clean ghost items on load");
    this.Text("Mod-UnequipMods-Set-Cleanup-Desc", "Removes blank dummy parts left in old saves by other tools. Runs once a few seconds after loading.");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-UnequipMods-Returned", "Mods devolvidos ao inventário");
    this.Text("Mod-UnequipMods-Title", "Unequip Mods");
    this.Text("Mod-UnequipMods-Set-Sell", "Extrair mods ao vender");
    this.Text("Mod-UnequipMods-Set-Sell-Desc", "Mods voltam pro inventário antes de o item ser vendido, incluindo venda em massa e drop points.");
    this.Text("Mod-UnequipMods-Set-Disassemble", "Extrair mods ao desmanchar");
    this.Text("Mod-UnequipMods-Set-Disassemble-Desc", "Mods voltam pro inventário antes de o item ser desmanchado.");
    this.Text("Mod-UnequipMods-Set-Drop", "Extrair mods ao largar");
    this.Text("Mod-UnequipMods-Set-Drop-Desc", "Mods voltam pro inventário antes de o item ser largado no chão.");
    this.Text("Mod-UnequipMods-Set-Toast", "Mostrar notificação");
    this.Text("Mod-UnequipMods-Set-Toast-Desc", "Mensagem na tela com a contagem de mods devolvidos.");
    this.Text("Mod-UnequipMods-Set-Cleanup", "Limpar itens fantasma no load");
    this.Text("Mod-UnequipMods-Set-Cleanup-Desc", "Remove partes vazias deixadas em saves antigos por outras ferramentas. Roda uma vez, segundos após carregar.");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
