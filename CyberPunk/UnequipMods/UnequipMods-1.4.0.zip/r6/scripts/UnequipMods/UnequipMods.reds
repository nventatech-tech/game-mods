// UnequipMods - weapon and clothing mods can be unequipped back to the inventory
// Requires: redscript, Codeware
module UnequipMods
import Codeware.Localization.*

// Vanilla only allows unequipping iconic mods; scopes, muzzles and programs were already free.
// Integral cyberware parts (knuckles, mantis edge, wires, launcher rounds) stay blocked.
@wrapMethod(RPGManager)
public final static func CanPartBeUnequipped(data: InventoryItemData, slotId: TweakDBID) -> Bool {
  let type: gamedataItemType = RPGManager.GetItemType(data.ID);
  if RPGManager.IsWeaponMod(type) || RPGManager.IsClothingMod(type) {
    return true;
  };
  return wrappedMethod(data, slotId);
}

// Parts worth saving: mods plus the attachments vanilla already lets you detach.
// Loot-generated weapons carry DummyBlankMod placeholders (typed as mods) that
// occupy hidden slots — extracting those creates blank items, so skip them.
func UnequipModsIsRemovablePart(id: ItemID) -> Bool {
  let record = TweakDBInterface.GetItemRecord(ItemID.GetTDBID(id));
  if !IsDefined(record) || record.TagsContains(n"DummyPart") || record.TagsContains(n"HideInUI") {
    return false;
  };
  let type = RPGManager.GetItemType(id);
  if RPGManager.IsWeaponMod(type) || RPGManager.IsClothingMod(type) {
    return true;
  };
  return Equals(type, gamedataItemType.Prt_ShortScope)
    || Equals(type, gamedataItemType.Prt_LongScope)
    || Equals(type, gamedataItemType.Prt_Muzzle)
    || Equals(type, gamedataItemType.Prt_HandgunMuzzle)
    || Equals(type, gamedataItemType.Prt_RifleMuzzle);
}

// Detaches every removable part of a weapon/clothing item back to the owner's inventory.
// Only player-facing slots are touched (same lists the vanilla disassemble restore uses);
// hidden slots hold internals like the untagged iconic ranged mods — stripping those
// creates ghost items and kills the iconic effect.
func UnequipModsStripParts(game: GameInstance, owner: wref<GameObject>, itemID: ItemID) -> Int32 {
  if !RPGManager.IsItemWeapon(itemID) && !RPGManager.IsItemClothing(itemID) {
    return 0;
  };
  let ts = GameInstance.GetTransactionSystem(game);
  let itemData = ts.GetItemData(owner, itemID);
  if !IsDefined(itemData) {
    return 0;
  };
  let allowedSlots = RPGManager.GetAttachmentSlotIDs();
  let modSlots = RPGManager.GetModsSlotIDs(itemData.GetItemType());
  for modSlot in modSlots {
    ArrayPush(allowedSlots, modSlot);
  };
  let usedSlots: array<TweakDBID>;
  ts.GetUsedSlotsOnItem(owner, itemID, usedSlots);
  let count = 0;
  for slot in usedSlots {
    if ArrayContains(allowedSlots, slot) {
      let partData: InnerItemData;
      itemData.GetItemPart(partData, slot);
      if UnequipModsIsRemovablePart(InnerItemData.GetItemID(partData)) {
        ts.RemovePart(owner, itemID, slot);
        count += 1;
      };
    };
  };
  return count;
}

// Removes ghost items (blank dummy parts extracted by older versions or other sources)
// already sitting in the inventory. DummyPart only — a generic HideInUI sweep could
// delete quest or system items.
func UnequipModsCleanupGhosts(player: ref<PlayerPuppet>) {
  let ts = GameInstance.GetTransactionSystem(player.GetGame());
  let items: array<wref<gameItemData>>;
  ts.GetItemList(player, items);
  for data in items {
    if IsDefined(data) {
      let id = data.GetID();
      let type = RPGManager.GetItemType(id);
      if RPGManager.IsWeaponMod(type) || RPGManager.IsClothingMod(type) {
        let record = TweakDBInterface.GetItemRecord(ItemID.GetTDBID(id));
        if IsDefined(record) && record.TagsContains(n"DummyPart") {
          ts.RemoveItem(player, id, data.GetQuantity());
        };
      };
    };
  };
}

public class UnequipModsCleanupCallback extends DelayCallback {
  public let player: wref<PlayerPuppet>;

  public func Call() {
    if IsDefined(this.player) && UnequipModsCleanupOnLoad() {
      UnequipModsCleanupGhosts(this.player);
    };
  }
}

// Delayed so the inventory is fully streamed in before the sweep.
@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  let result = wrappedMethod();
  let callback = new UnequipModsCleanupCallback();
  callback.player = this;
  GameInstance.GetDelaySystem(this.GetGame()).DelayCallback(callback, 5.0, false);
  return result;
}

func UnequipModsNotify(game: GameInstance, count: Int32) {
  if count <= 0 || !UnequipModsShowToast() {
    return;
  };
  let msg: SimpleScreenMessage;
  msg.isShown = true;
  msg.duration = 5.0;
  msg.message = LocalizationSystem.GetInstance(game).GetText("Mod-UnequipMods-Returned") + s": \(count)";
  GameInstance.GetBlackboardSystem(game).Get(GetAllBlackboardDefs().UI_Notifications)
    .SetVariant(GetAllBlackboardDefs().UI_Notifications.OnscreenMessage, ToVariant(msg), true);
}

// Single-item sales route through this too, so one wrap covers unit sell,
// junk bulk sell and drop points.
@wrapMethod(VendorDataManager)
public final func SellItemsToVendor(const itemsData: script_ref<array<wref<gameItemData>>>, const amounts: script_ref<array<Int32>>, opt requestId: Int32) {
  let game = GetGameInstance();
  if UnequipModsStripOnSell() {
    let player = GameInstance.GetPlayerSystem(game).GetLocalPlayerMainGameObject();
    let total = 0;
    let i = 0;
    while i < ArraySize(Deref(itemsData)) {
      total += UnequipModsStripParts(game, player, Deref(itemsData)[i].GetID());
      i += 1;
    };
    UnequipModsNotify(game, total);
  };
  wrappedMethod(itemsData, amounts, requestId);
}

// Vanilla disassemble only restores a few attachments; strip everything first.
@wrapMethod(CraftingSystem)
private final const func DisassembleItem(target: wref<GameObject>, itemID: ItemID, amount: Int32) -> Void {
  if UnequipModsStripOnDisassemble() {
    let count = UnequipModsStripParts(GetGameInstance(), target, itemID);
    UnequipModsNotify(GetGameInstance(), count);
  };
  wrappedMethod(target, itemID, amount);
}

// Dropping was the last way to silently lose mods; strip before the item leaves
@wrapMethod(ItemActionsHelper)
public final static func DropItem(executor: wref<GameObject>, itemID: ItemID) -> Void {
  if UnequipModsStripOnDrop() && IsDefined(executor) {
    let count = UnequipModsStripParts(executor.GetGame(), executor, itemID);
    UnequipModsNotify(executor.GetGame(), count);
  };
  wrappedMethod(executor, itemID);
}

@wrapMethod(RPGManager)
public final static func DropManyItems(gameInstance: GameInstance, obj: wref<GameObject>, const items: script_ref<[ItemModParams]>) -> Void {
  if UnequipModsStripOnDrop() && IsDefined(obj) {
    let total = 0;
    let i = 0;
    while i < ArraySize(Deref(items)) {
      total += UnequipModsStripParts(gameInstance, obj, Deref(items)[i].itemID);
      i += 1;
    };
    UnequipModsNotify(gameInstance, total);
  };
  wrappedMethod(gameInstance, obj, items);
}
