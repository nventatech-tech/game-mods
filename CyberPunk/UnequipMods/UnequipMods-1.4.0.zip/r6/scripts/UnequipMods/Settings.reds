// Options shown in the Mod Settings menu. Mod Settings is optional: without it the defaults apply.
module UnequipMods

public class UnequipModsSettings extends ScriptableSystem {

  @runtimeProperty("ModSettings.mod", "Mod-UnequipMods-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-UnequipMods-Set-Sell")
  @runtimeProperty("ModSettings.description", "Mod-UnequipMods-Set-Sell-Desc")
  public let stripOnSell: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-UnequipMods-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-UnequipMods-Set-Disassemble")
  @runtimeProperty("ModSettings.description", "Mod-UnequipMods-Set-Disassemble-Desc")
  public let stripOnDisassemble: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-UnequipMods-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-UnequipMods-Set-Drop")
  @runtimeProperty("ModSettings.description", "Mod-UnequipMods-Set-Drop-Desc")
  public let stripOnDrop: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-UnequipMods-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-UnequipMods-Set-Toast")
  @runtimeProperty("ModSettings.description", "Mod-UnequipMods-Set-Toast-Desc")
  public let showToast: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-UnequipMods-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-UnequipMods-Set-Cleanup")
  @runtimeProperty("ModSettings.description", "Mod-UnequipMods-Set-Cleanup-Desc")
  public let cleanupOnLoad: Bool = true;

  public static func Get(game: GameInstance) -> ref<UnequipModsSettings> {
    return GameInstance.GetScriptableSystemsContainer(game).Get(n"UnequipMods.UnequipModsSettings") as UnequipModsSettings;
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {}

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.UnregisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {}
}

public func UnequipModsStripOnSell() -> Bool {
  let s: ref<UnequipModsSettings> = UnequipModsSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.stripOnSell;
}

public func UnequipModsStripOnDisassemble() -> Bool {
  let s: ref<UnequipModsSettings> = UnequipModsSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.stripOnDisassemble;
}

public func UnequipModsStripOnDrop() -> Bool {
  let s: ref<UnequipModsSettings> = UnequipModsSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.stripOnDrop;
}

public func UnequipModsShowToast() -> Bool {
  let s: ref<UnequipModsSettings> = UnequipModsSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.showToast;
}

public func UnequipModsCleanupOnLoad() -> Bool {
  let s: ref<UnequipModsSettings> = UnequipModsSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.cleanupOnLoad;
}
