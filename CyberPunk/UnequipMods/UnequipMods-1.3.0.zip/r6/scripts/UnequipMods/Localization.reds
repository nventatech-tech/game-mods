// Translations for UnequipMods. Add a package + a case in GetPackage to support a new language.
module UnequipMods.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-UnequipMods-Returned", "Mods returned to inventory");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-UnequipMods-Returned", "Mods devolvidos ao inventário");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
