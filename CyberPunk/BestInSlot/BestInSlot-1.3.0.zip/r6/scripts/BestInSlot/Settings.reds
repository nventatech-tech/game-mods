// Options shown in the Mod Settings menu. Mod Settings is optional: without it the defaults apply.
module BestInSlot

public class BestInSlotSettings extends ScriptableSystem {

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-UpgradeBadge")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-UpgradeBadge-Desc")
  public let showUpgradeBadge: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-SellClothes")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-SellClothes-Desc")
  public let sellClothes: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-EquipConsumables")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-EquipConsumables-Desc")
  public let equipConsumables: Bool = true;

  public static func Get(game: GameInstance) -> ref<BestInSlotSettings> {
    return GameInstance.GetScriptableSystemsContainer(game).Get(n"BestInSlot.BestInSlotSettings") as BestInSlotSettings;
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {}

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.UnregisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {}
}

public func BisSellClothes() -> Bool {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.sellClothes;
}

public func BisShowUpgradeBadge() -> Bool {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.showUpgradeBadge;
}

public func BisEquipConsumables() -> Bool {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.equipConsumables;
}
