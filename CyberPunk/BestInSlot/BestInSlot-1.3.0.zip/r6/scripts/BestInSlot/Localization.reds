// Translations for BestInSlot. Add a package + a case in GetPackage to support a new language.
module BestInSlot.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-Marked", "TOP items marked");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "equip best loadout");
    this.Text("Mod-BestInSlot-Bar-Equipped", "Best loadout equipped");
    this.Text("Mod-BestInSlot-Bar-Items", "items");
    this.Text("Mod-BestInSlot-Title", "Best In Slot");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge", "Upgrade (+) badge");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge-Desc", "Green (+) on items that beat the one you have equipped in the same slot or type.");
    this.Text("Mod-BestInSlot-Set-SellClothes", "Bulk-sell includes clothes");
    this.Text("Mod-BestInSlot-Set-SellClothes-Desc", "N at a vendor also sells clothes without the TOP badge. Equipped, iconic and quest items never sell.");
    this.Text("Mod-BestInSlot-Set-EquipConsumables", "Equip best consumables");
    this.Text("Mod-BestInSlot-Set-EquipConsumables-Desc", "B also slots the best healing item and grenade. Off equips weapons and clothes only.");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-Marked", "itens TOP marcados");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "equipar os melhores");
    this.Text("Mod-BestInSlot-Bar-Equipped", "Melhor equipamento aplicado");
    this.Text("Mod-BestInSlot-Bar-Items", "itens");
    this.Text("Mod-BestInSlot-Title", "Best In Slot");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge", "Selo (+) de upgrade");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge-Desc", "Selo (+) verde em item melhor que o equipado do mesmo slot ou tipo.");
    this.Text("Mod-BestInSlot-Set-SellClothes", "Venda em massa inclui roupas");
    this.Text("Mod-BestInSlot-Set-SellClothes-Desc", "N no vendedor também vende roupas sem o selo TOP. Equipados, icônicos e itens de missão nunca são vendidos.");
    this.Text("Mod-BestInSlot-Set-EquipConsumables", "Equipar melhores consumíveis");
    this.Text("Mod-BestInSlot-Set-EquipConsumables-Desc", "B também põe no slot o melhor item de cura e granada. Desligado, equipa só armas e roupas.");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
