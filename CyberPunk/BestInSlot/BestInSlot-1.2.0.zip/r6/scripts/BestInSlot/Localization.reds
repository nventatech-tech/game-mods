// Translations for BestInSlot. Add a package + a case in GetPackage to support a new language.
module BestInSlot.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-Marked", "TOP items marked");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "equip best loadout");
    this.Text("Mod-BestInSlot-Bar-Equipped", "Best loadout equipped");
    this.Text("Mod-BestInSlot-Bar-Items", "items");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-Marked", "itens TOP marcados");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "equipar os melhores");
    this.Text("Mod-BestInSlot-Bar-Equipped", "Melhor equipamento aplicado");
    this.Text("Mod-BestInSlot-Bar-Items", "itens");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
