// Translations for QuestGuide. Add a package + a case in GetPackage to support a new language.
module QuestGuide.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-QuestGuide-Title", "Quest Guide");
    this.Text("Mod-QuestGuide-Footer-Hint", "click: details");
    this.Text("Mod-QuestGuide-Footer-Close", "close");
    this.Text("Mod-QuestGuide-Set-Hotkey", "Hotkey");
    this.Text("Mod-QuestGuide-Set-Hotkey-Desc", "Key that opens and closes the quest guide. Only keys the game does not use and that never type into a text field.");
    this.Text("Mod-QuestGuide-Search-Placeholder", "Search quest...");
    this.Text("Mod-QuestGuide-Detail-Header", "DETAILS");
    this.Text("Mod-QuestGuide-Detail-Placeholder", "Click a quest.");
    this.Text("Mod-QuestGuide-Detail-NoDescription", "No description.");
    this.Text("Mod-QuestGuide-Detail-Unlocks", "Unlocks:");
    this.Text("Mod-QuestGuide-Detail-PointOfNoReturn", "Point of no return: finishing this quest ends the game, everything left becomes unreachable.");
    this.Text("Mod-QuestGuide-Quest-PointSuffix", "[point of no return]");
    this.Text("Mod-QuestGuide-Track-Tracked", "[ tracked ]");
    this.Text("Mod-QuestGuide-Track-Action", "[ TRACK ]");
    this.Text("Mod-QuestGuide-Quest-TrackedSuffix", "[tracked]");
    this.Text("Mod-QuestGuide-Section-Main", "MAIN STORY");
    this.Text("Mod-QuestGuide-Section-Ending", "AFFECTS ENDING");
    this.Text("Mod-QuestGuide-Section-Cosmetic", "COSMETIC");
    this.Text("Mod-QuestGuide-Section-Gigs", "GIGS");
    this.Text("Mod-QuestGuide-Section-PhantomLiberty", "PHANTOM LIBERTY");
    this.Text("Mod-QuestGuide-Section-Cyberpsycho", "CYBERPSYCHO SIGHTINGS");
    this.Text("Mod-QuestGuide-Section-Ncpd", "NCPD - REPORTED CRIME");
    this.Text("Mod-QuestGuide-State-Active", "active");
    this.Text("Mod-QuestGuide-State-Pending", "pending");
    this.Text("Mod-QuestGuide-State-Done", "done");
    this.Text("Mod-QuestGuide-State-Failed", "failed");
    this.Text("Mod-QuestGuide-Progress-Done", "done");
    this.Text("Mod-QuestGuide-Objective-Optional", "(optional)");
    this.Text("Mod-QuestGuide-Ending-Star", "The Star ending (Panam path)");
    this.Text("Mod-QuestGuide-Ending-Sun", "The Sun ending and the secret ending (Johnny chain)");
    this.Text("Mod-QuestGuide-Ending-JohnnyChain", "Johnny chain towards the secret ending");
    this.Text("Mod-QuestGuide-Ending-JudyRomance", "Judy romance (changes the epilogue)");
    this.Text("Mod-QuestGuide-Ending-RiverRomance", "River romance (changes the epilogue)");
    this.Text("Mod-QuestGuide-Ending-KerryChain", "Kerry chain/romance (changes the epilogue)");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-QuestGuide-Title", "Guia de Missões");
    this.Text("Mod-QuestGuide-Footer-Hint", "clique: detalhes");
    this.Text("Mod-QuestGuide-Footer-Close", "fechar");
    this.Text("Mod-QuestGuide-Set-Hotkey", "Tecla");
    this.Text("Mod-QuestGuide-Set-Hotkey-Desc", "Tecla que abre e fecha o guia. Só teclas que o jogo não usa e que nunca digitam em campo de texto.");
    this.Text("Mod-QuestGuide-Search-Placeholder", "Buscar missão...");
    this.Text("Mod-QuestGuide-Detail-Header", "DETALHE");
    this.Text("Mod-QuestGuide-Detail-Placeholder", "Clique numa missão.");
    this.Text("Mod-QuestGuide-Detail-NoDescription", "Sem descrição.");
    this.Text("Mod-QuestGuide-Detail-Unlocks", "Desbloqueia:");
    this.Text("Mod-QuestGuide-Detail-PointOfNoReturn", "Ponto sem retorno: terminar esta missão encerra o jogo, o que sobrar fica inacessível.");
    this.Text("Mod-QuestGuide-Quest-PointSuffix", "[ponto sem retorno]");
    this.Text("Mod-QuestGuide-Track-Tracked", "[ rastreada ]");
    this.Text("Mod-QuestGuide-Track-Action", "[ RASTREAR ]");
    this.Text("Mod-QuestGuide-Quest-TrackedSuffix", "[rastreada]");
    this.Text("Mod-QuestGuide-Section-Main", "PRINCIPAL");
    this.Text("Mod-QuestGuide-Section-Ending", "AFETA O FINAL");
    this.Text("Mod-QuestGuide-Section-Cosmetic", "COSMÉTICA");
    this.Text("Mod-QuestGuide-Section-Gigs", "GIGS");
    this.Text("Mod-QuestGuide-Section-PhantomLiberty", "PHANTOM LIBERTY");
    this.Text("Mod-QuestGuide-Section-Cyberpsycho", "CIBERPSICOPATAS");
    this.Text("Mod-QuestGuide-Section-Ncpd", "NCPD - CRIME RELATADO");
    this.Text("Mod-QuestGuide-State-Active", "ativa");
    this.Text("Mod-QuestGuide-State-Pending", "pendente");
    this.Text("Mod-QuestGuide-State-Done", "concluída");
    this.Text("Mod-QuestGuide-State-Failed", "falhou");
    this.Text("Mod-QuestGuide-Progress-Done", "concluídas");
    this.Text("Mod-QuestGuide-Objective-Optional", "(opcional)");
    this.Text("Mod-QuestGuide-Ending-Star", "final The Star (caminho da Panam)");
    this.Text("Mod-QuestGuide-Ending-Sun", "final The Sun e o final secreto (cadeia do Johnny)");
    this.Text("Mod-QuestGuide-Ending-JohnnyChain", "cadeia do Johnny rumo ao final secreto");
    this.Text("Mod-QuestGuide-Ending-JudyRomance", "romance da Judy (muda o epílogo)");
    this.Text("Mod-QuestGuide-Ending-RiverRomance", "romance do River (muda o epílogo)");
    this.Text("Mod-QuestGuide-Ending-KerryChain", "cadeia/romance do Kerry (muda o epílogo)");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
