// QuestGuide - quest guide with native UI: real main story vs. affects the ending vs. cosmetic,
// with live journal state
// Requires: redscript, Codeware
module QuestGuide
import Codeware.UI.*
import Codeware.Localization.*

enum QGCategory {
  Main = 0,
  Ending = 1,
  Cosmetic = 2,
  Gig = 3,
  PhantomLiberty = 4,
  Cyberpsycho = 5,
  Ncpd = 6
}

public struct QGQuest {
  public let entry: wref<JournalQuest>;
  public let title: String;
  public let path: String;
  public let category: QGCategory;
  public let state: gameJournalEntryState;
  public let tracked: Bool;
  public let search: String;
  public let fixer: Int32;
}

// gigs live under quests/street_stories/<district>/<area>/sts_... and, in Phantom Liberty,
// under ep1/quests/street_stories (Dogtown, no district folder). One fixer per district.
public func QGFixerCount() -> Int32 {
  return 9;
}

public func QGFixerName(idx: Int32) -> String {
  switch idx {
    case 0: return "REGINA JONES - WATSON";
    case 1: return "WAKAKO OKADA - WESTBROOK";
    case 2: return "SEBASTIAN IBARRA - HEYWOOD";
    case 3: return "EL CAPITAN - CITY CENTER";
    case 4: return "DINO DINOVIC - SANTO DOMINGO";
    case 5: return "MR. HANDS - PACIFICA";
    case 6: return "DAKOTA SMITH - BADLANDS";
    case 7: return "MR. HANDS - DOGTOWN";
    default: return "";
  };
}

// -1 when the quest is not a gig; QGFixerCount() - 1 for a district we do not know
public func QGFixerFromPath(path: String) -> Int32 {
  if !StrContains(path, "street_stories") {
    return -1;
  };
  if StrContains(path, "ep1/") {
    return 7;
  };
  if StrContains(path, "/watson/") {
    return 0;
  };
  if StrContains(path, "/westbrook/") {
    return 1;
  };
  if StrContains(path, "/heywood/") {
    return 2;
  };
  if StrContains(path, "/city_center/") {
    return 3;
  };
  if StrContains(path, "/santo_domingo/") {
    return 4;
  };
  if StrContains(path, "/pacifica/") {
    return 5;
  };
  if StrContains(path, "/badlands/") {
    return 6;
  };
  return QGFixerCount() - 1;
}

// quests that lock the rest of the game once finished (journal id, no folder)
public func QGPointOfNoReturnIds() -> array<String> {
  return ["02_sickness"]; // Nocturne Op55N1
}

public func QGIsPointOfNoReturn(id: String) -> Bool {
  return QGHas(QGPointOfNoReturnIds(), id);
}

// side jobs that gate an ending or a romance payoff -> Ending; other sides -> Cosmetic
public func QGEndingSideIds() -> array<String> {
  return [
    "sq004_riders_on_the_storm", // Panam -> The Star
    "sq031_rogue",               // Chippin' In -> The Sun + the secret ending
    "sq031_smack_my_bitch_up",   // A Cool Metal Fire
    "sq031_cinema",              // Blistering Love -> call Rogue
    "sq030_judy_romance",
    "sq028_kerry_romance",
    "sq029_sobchak_romance",
    "sq021_sick_dreams",         // The Hunt (River)
    "sq011_kerry", "sq017_kerry", "sq011_concert", "sq011_johnny",
    "sq017_02_lounge"            // Kerry chain
  ];
}

// the base main story lives under quests/meta/ (Nocturne = meta/02_sickness);
// everything there is main except these
public func QGMetaCosmeticIds() -> array<String> {
  return ["07_nc_underground", "08_headhunter"];
}

func QGHas(ids: array<String>, id: String) -> Bool {
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    if Equals(ids[i], id) {
      return true;
    };
    i += 1;
  };
  return false;
}

// category from the journal folder: main_quest -> Main; /meta/<id> -> Main except the
// cosmetic list; side_quest/<id> -> Ending if listed, else Cosmetic; rest -> Cosmetic
public func QGCategoryFromPath(path: String) -> QGCategory {
  if StrContains(path, "street_stories") {
    return QGCategory.Gig;
  };
  // everything under ep1/ is Phantom Liberty; its main quests carry "main_quest" too and would
  // otherwise land in the base game story
  if StrContains(path, "ep1/") {
    return QGCategory.PhantomLiberty;
  };
  if StrContains(path, "minor_activities") {
    return QGCategory.Ncpd;
  };
  // cyberpsycho sightings sit in minor_quest with the ma_ prefix, next to regular minor jobs
  if StrContains(path, "minor_quest") && StrContains(path, "/ma_") {
    return QGCategory.Cyberpsycho;
  };
  if StrContains(path, "main_quest") {
    return QGCategory.Main;
  };
  let segs: array<String> = StrSplit(path, "/");
  let i: Int32 = 0;
  while i < ArraySize(segs) - 1 {
    if i > 0 && Equals(segs[i], "meta") {
      return QGHas(QGMetaCosmeticIds(), segs[i + 1]) ? QGCategory.Cosmetic : QGCategory.Main;
    };
    if Equals(segs[i], "side_quest") {
      return QGHas(QGEndingSideIds(), segs[i + 1]) ? QGCategory.Ending : QGCategory.Cosmetic;
    };
    i += 1;
  };
  return QGCategory.Cosmetic;
}

// journal path rebuilt by walking up the parents (folder = category)
public func QGEntryPath(jm: ref<JournalManager>, entry: wref<JournalEntry>) -> String {
  let path: String = entry.GetId();
  let parent: wref<JournalEntry> = jm.GetParentEntry(entry);
  let guard: Int32 = 0;
  while IsDefined(parent) && guard < 20 {
    path = parent.GetId() + "/" + path;
    parent = jm.GetParentEntry(parent);
    guard += 1;
  };
  return path;
}

public func QGBuildQuestList(game: GameInstance) -> array<QGQuest> {
  let result: array<QGQuest>;
  let jm: ref<JournalManager> = GameInstance.GetJournalManager(game);
  if !IsDefined(jm) {
    return result;
  };
  let context: JournalRequestContext;
  context.stateFilter.active = true;
  context.stateFilter.inactive = true;
  context.stateFilter.succeeded = true;
  context.stateFilter.failed = true;
  let entries: array<wref<JournalEntry>>;
  jm.GetQuests(context, entries);
  let tracked: wref<JournalEntry> = jm.GetTrackedEntry();
  let i: Int32 = 0;
  while i < ArraySize(entries) {
    let quest: wref<JournalQuest> = entries[i] as JournalQuest;
    // the journal carries a placeholder gig entry ("Undiscovered") that is not a real quest
    if IsDefined(quest) && !Equals(quest.GetId(), "generic_sts_quest") {
      let item: QGQuest;
      item.entry = quest;
      item.title = GetLocalizedText(quest.GetTitle(jm));
      if Equals(item.title, "") {
        item.title = "?";
      };
      item.path = QGEntryPath(jm, quest);
      item.category = QGCategoryFromPath(item.path);
      item.fixer = QGFixerFromPath(item.path);
      item.state = jm.GetEntryState(quest);
      item.tracked = IsDefined(tracked) && tracked == quest;
      item.search = UTF8StrLower(item.title);
      QGInsertSorted(result, item);
    };
    i += 1;
  };
  return result;
}

// description + objective texts of a quest, flattened for the search filter
func QGQuestText(jm: ref<JournalManager>, entry: wref<JournalQuest>) -> String {
  let filter: JournalRequestStateFilter;
  filter.active = true;
  filter.succeeded = true;
  filter.failed = true;
  let children: array<wref<JournalEntry>>;
  jm.GetChildren(entry, filter, children);
  let text: String = "";
  let i: Int32 = 0;
  while i < ArraySize(children) {
    let desc: wref<JournalQuestDescription> = children[i] as JournalQuestDescription;
    if IsDefined(desc) {
      text += " " + QGLocText(desc.GetDescription());
    };
    let obj: wref<JournalQuestObjective> = children[i] as JournalQuestObjective;
    if IsDefined(obj) {
      text += " " + QGLocText(obj.GetDescription());
    };
    let phase: wref<JournalQuestPhase> = children[i] as JournalQuestPhase;
    if IsDefined(phase) {
      let objs: array<wref<JournalEntry>>;
      jm.GetChildren(phase, filter, objs);
      let j: Int32 = 0;
      while j < ArraySize(objs) {
        let pObj: wref<JournalQuestObjective> = objs[j] as JournalQuestObjective;
        if IsDefined(pObj) {
          text += " " + QGLocText(pObj.GetDescription());
        };
        j += 1;
      };
    };
    i += 1;
  };
  return text;
}

// sorted insert by state (active > pending > done > failed), title as
// tiebreaker (small list, no native sort in redscript)
func QGInsertSorted(out list: array<QGQuest>, item: QGQuest) {
  let key: Int32 = QGStateToggleIdx(item.state);
  let i: Int32 = 0;
  while i < ArraySize(list) {
    let k: Int32 = QGStateToggleIdx(list[i].state);
    if k > key || k == key && UnicodeStringCompare(list[i].title, item.title) > 0 {
      break;
    };
    i += 1;
  };
  ArrayInsert(list, i, item);
}

public func QGTrackQuest(game: GameInstance, entry: wref<JournalQuest>) {
  GameInstance.GetJournalManager(game).TrackEntry(entry);
}

// UI: native popup (Codeware CustomPopup infra), single list grouped by
// category (name colored by state + gray state word) and a detail panel
// on the right filled on hover. Toggled with the configured key.

func QGStateColor(state: gameJournalEntryState) -> HDRColor {
  if Equals(state, gameJournalEntryState.Succeeded) {
    return new HDRColor(0.30, 0.85, 0.35, 1.0);
  };
  if Equals(state, gameJournalEntryState.Active) {
    return new HDRColor(1.00, 0.82, 0.00, 1.0);
  };
  if Equals(state, gameJournalEntryState.Failed) {
    return new HDRColor(0.90, 0.35, 0.30, 1.0);
  };
  return new HDRColor(0.62, 0.62, 0.64, 1.0);
}

// state filter toggles: 0=active 1=pending 2=done 3=failed
func QGStateToggleIdx(state: gameJournalEntryState) -> Int32 {
  if Equals(state, gameJournalEntryState.Active) {
    return 0;
  };
  if Equals(state, gameJournalEntryState.Succeeded) {
    return 2;
  };
  if Equals(state, gameJournalEntryState.Failed) {
    return 3;
  };
  return 1;
}

func QGStateShowLabel(idx: Int32, loc: ref<LocalizationSystem>) -> String {
  if idx == 0 {
    return loc.GetText("Mod-QuestGuide-State-Active");
  };
  if idx == 1 {
    return loc.GetText("Mod-QuestGuide-State-Pending");
  };
  if idx == 2 {
    return loc.GetText("Mod-QuestGuide-State-Done");
  };
  return loc.GetText("Mod-QuestGuide-State-Failed");
}

func QGStateShowColor(idx: Int32) -> HDRColor {
  if idx == 0 {
    return new HDRColor(1.00, 0.82, 0.00, 1.0);
  };
  if idx == 1 {
    return new HDRColor(0.62, 0.62, 0.64, 1.0);
  };
  if idx == 2 {
    return new HDRColor(0.30, 0.85, 0.35, 1.0);
  };
  return new HDRColor(0.90, 0.35, 0.30, 1.0);
}

// line estimate for the scroll clamp (StrLen in bytes overestimates with accents; harmless slack)
func QGEstLines(text: String, charsPerLine: Int32) -> Int32 {
  return StrLen(text) / charsPerLine + 1;
}

func QGStateWord(state: gameJournalEntryState, loc: ref<LocalizationSystem>) -> String {
  if Equals(state, gameJournalEntryState.Succeeded) {
    return loc.GetText("Mod-QuestGuide-State-Done");
  };
  if Equals(state, gameJournalEntryState.Active) {
    return loc.GetText("Mod-QuestGuide-State-Active");
  };
  if Equals(state, gameJournalEntryState.Failed) {
    return loc.GetText("Mod-QuestGuide-State-Failed");
  };
  return loc.GetText("Mod-QuestGuide-State-Pending");
}

// raj font is missing several unicode glyphs ("—" becomes "?"), prefixes stay ASCII-only
func QGStatePrefix(state: gameJournalEntryState) -> String {
  if Equals(state, gameJournalEntryState.Succeeded) {
    return "+ ";
  };
  if Equals(state, gameJournalEntryState.Active) {
    return "> ";
  };
  if Equals(state, gameJournalEntryState.Failed) {
    return "x ";
  };
  return "- ";
}

// curated reason for each "Ending" side quest (paired with QGEndingSideIds) for the detail panel
func QGEndingReason(id: String, loc: ref<LocalizationSystem>) -> String {
  if Equals(id, "sq004_riders_on_the_storm") {
    return loc.GetText("Mod-QuestGuide-Ending-Star");
  };
  if Equals(id, "sq031_rogue") {
    return loc.GetText("Mod-QuestGuide-Ending-Sun");
  };
  if Equals(id, "sq031_smack_my_bitch_up") || Equals(id, "sq031_cinema") {
    return loc.GetText("Mod-QuestGuide-Ending-JohnnyChain");
  };
  if Equals(id, "sq030_judy_romance") {
    return loc.GetText("Mod-QuestGuide-Ending-JudyRomance");
  };
  if Equals(id, "sq029_sobchak_romance") || Equals(id, "sq021_sick_dreams") {
    return loc.GetText("Mod-QuestGuide-Ending-RiverRomance");
  };
  if Equals(id, "sq028_kerry_romance") || Equals(id, "sq011_kerry") || Equals(id, "sq017_kerry")
      || Equals(id, "sq011_concert") || Equals(id, "sq011_johnny") || Equals(id, "sq017_02_lounge") {
    return loc.GetText("Mod-QuestGuide-Ending-KerryChain");
  };
  return "";
}

// journal GetDescription can come back as a raw "LocKey#..."; resolve it when that happens
func QGLocText(raw: String) -> String {
  let loc: String = GetLocalizedText(raw);
  return Equals(loc, "") ? raw : loc;
}

public class QuestGuidePopup extends InGamePopup {
  protected let m_header: ref<InGamePopupHeader>;
  protected let m_footer: ref<InGamePopupFooter>;
  protected let m_content: ref<InGamePopupContent>;
  protected let m_scrollContent: wref<inkVerticalPanel>;
  protected let m_contentHeight: Float;
  protected let m_scrollOffset: Float;
  protected let m_search: ref<HubTextInput>;
  protected let m_stateToggles: array<wref<inkText>>;
  protected let m_stateShow: array<Bool>;
  protected let m_listPanel: wref<inkVerticalPanel>;
  protected let m_quests: array<QGQuest>;
  protected let m_hoverRows: array<wref<inkWidget>>;
  protected let m_hoverNames: array<wref<inkText>>;
  protected let m_hoverQuests: array<Int32>;
  protected let m_selected: Int32;
  protected let m_overDetail: Bool;
  protected let m_detailTitle: wref<inkText>;
  protected let m_trackBtn: wref<inkText>;
  protected let m_detailContent: wref<inkVerticalPanel>;
  protected let m_detailScroll: Float;
  protected let m_detailHeight: Float;
  protected let m_detailDesc: wref<inkText>;
  protected let m_detailObjectives: wref<inkVerticalPanel>;
  protected let m_detailUnlock: wref<inkText>;
  protected let m_detailPoint: wref<inkText>;
  protected let m_trackedY: Float;
  protected let m_sectionHeads: array<wref<inkText>>;
  protected let m_sectionOpen: array<Bool>;
  protected let m_sectionSlots: array<Int32>;
  protected let m_searchIndexed: Bool;

  public func GetName() -> CName {
    return n"QuestGuidePopup";
  }

  public func UseCursor() -> Bool {
    return true;
  }

  public func QGIsOpen() -> Bool {
    return this.IsInitialized();
  }

  protected func QGLoc() -> ref<LocalizationSystem> {
    return LocalizationSystem.GetInstance(this.GetGame());
  }

  protected cb func OnCreate() {
    super.OnCreate();
    this.m_container.SetSize(Vector2(2600.0, 1340.0));
    let loc: ref<LocalizationSystem> = this.QGLoc();

    this.m_header = InGamePopupHeader.Create();
    this.m_header.SetTitle(loc.GetText("Mod-QuestGuide-Title"));
    this.m_header.SetFluffLeft("v1.3.0"); // Codeware's default shows the raw loc key
    this.m_header.SetFluffRight("QUESTGUIDE");
    this.m_header.Reparent(this);

    this.m_footer = InGamePopupFooter.Create();
    this.m_footer.SetFluffIcon(n"fluff_triangle2");
    this.m_footer.SetFluffText(loc.GetText("Mod-QuestGuide-Footer-Hint")
      + "   [" + QuestGuideSettings.LabelOf(this.GetGame()) + "] "
      + loc.GetText("Mod-QuestGuide-Footer-Close"));
    this.m_footer.Reparent(this);

    this.m_content = InGamePopupContent.Create();
    this.m_content.Reparent(this);

    let outer: ref<inkVerticalPanel> = new inkVerticalPanel();
    outer.SetName(n"outer");
    outer.Reparent(this.m_content.GetRootCompoundWidget());

    let topRow: ref<inkHorizontalPanel> = new inkHorizontalPanel();
    topRow.SetName(n"topRow");
    topRow.SetMargin(inkMargin(0.0, 0.0, 0.0, 8.0));
    topRow.Reparent(outer);

    this.m_search = HubTextInput.Create();
    this.m_search.SetName(n"search");
    this.m_search.SetDefaultText(loc.GetText("Mod-QuestGuide-Search-Placeholder"));
    this.m_search.SetMaxLength(64);
    this.m_search.SetWidth(700.0);
    this.m_search.GetRootWidget().SetVAlign(inkEVerticalAlign.Top);
    this.m_search.Reparent(topRow);
    this.m_search.RegisterToCallback(n"OnInput", this, n"OnSearchInput");

    let body: ref<inkHorizontalPanel> = new inkHorizontalPanel();
    body.SetName(n"body");
    body.Reparent(outer);

    // single scrollable list with sections by category (GME-style)
    let viewport: ref<inkScrollArea> = new inkScrollArea();
    viewport.SetSize(Vector2(950.0, 900.0));
    viewport.SetUseInternalMask(true);
    viewport.SetConstrainContentPosition(true);
    viewport.Reparent(body);

    let list: ref<inkVerticalPanel> = new inkVerticalPanel();
    list.SetName(n"list");
    list.Reparent(viewport);
    this.m_listPanel = list;
    this.m_scrollContent = list;

    // state filters next to the search box, two per column: a single 4-high column would set the
    // row height and push the list down
    let filters: ref<inkHorizontalPanel> = new inkHorizontalPanel();
    filters.SetName(n"filters");
    filters.SetMargin(inkMargin(40.0, 0.0, 0.0, 0.0));
    filters.SetVAlign(inkEVerticalAlign.Top);
    filters.Reparent(topRow);

    let filtersA: ref<inkVerticalPanel> = new inkVerticalPanel();
    filtersA.Reparent(filters);
    let filtersB: ref<inkVerticalPanel> = new inkVerticalPanel();
    filtersB.SetMargin(inkMargin(32.0, 0.0, 0.0, 0.0));
    filtersB.Reparent(filters);

    let sc: Int32 = 0;
    while sc < 6 + QGFixerCount() {
      ArrayPush(this.m_sectionOpen, true);
      sc += 1;
    };

    let ti: Int32 = 0;
    while ti < 4 {
      ArrayPush(this.m_stateShow, true);
      let toggle: ref<inkText> = new inkText();
      toggle.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
      toggle.SetFontStyle(n"Medium");
      toggle.SetFontSize(25);
      toggle.SetFitToContent(true);
      toggle.SetMargin(inkMargin(0.0, ti % 2 == 0 ? 0.0 : 6.0, 0.0, 0.0));
      toggle.SetInteractive(true);
      toggle.Reparent(ti < 2 ? filtersA : filtersB);
      ArrayPush(this.m_stateToggles, toggle);
      ti += 1;
    };
    this.UpdateStateToggles();

    // detail panel fixed on the right; clicking a row fills it in
    let detail: ref<inkVerticalPanel> = new inkVerticalPanel();
    detail.SetName(n"detail");
    detail.SetMargin(inkMargin(40.0, 0.0, 0.0, 0.0));
    detail.SetInteractive(true);
    detail.RegisterToCallback(n"OnHoverOver", this, n"OnDetailHoverOver");
    detail.RegisterToCallback(n"OnHoverOut", this, n"OnDetailHoverOut");
    detail.Reparent(body);

    let dTitle: ref<inkText> = new inkText();
    dTitle.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    dTitle.SetFontStyle(n"Medium");
    dTitle.SetFontSize(34);
    dTitle.SetFitToContent(true);
    dTitle.SetWrapping(true, 1330.0);
    dTitle.SetMargin(inkMargin(0.0, 0.0, 0.0, 14.0));
    dTitle.SetTintColor(new HDRColor(0.62, 0.62, 0.64, 1.0));
    dTitle.SetText(loc.GetText("Mod-QuestGuide-Detail-Header"));
    dTitle.Reparent(detail);
    this.m_detailTitle = dTitle;

    // button to track the selected quest
    let track: ref<inkText> = new inkText();
    track.SetName(n"trackBtn");
    track.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    track.SetFontStyle(n"Medium");
    track.SetFontSize(30);
    track.SetFitToContent(true);
    track.SetMargin(inkMargin(0.0, 0.0, 0.0, 20.0));
    track.SetTintColor(new HDRColor(1.00, 0.82, 0.00, 1.0));
    track.SetInteractive(true);
    track.RegisterToCallback(n"OnHoverOver", this, n"OnDetailHoverOver");
    track.SetVisible(false);
    track.Reparent(detail);
    this.m_trackBtn = track;

    // "Unlocks:" line for quests that affect the ending
    let dUnlock: ref<inkText> = new inkText();
    dUnlock.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    dUnlock.SetFontStyle(n"Medium");
    dUnlock.SetFontSize(26);
    dUnlock.SetFitToContent(true);
    dUnlock.SetWrapping(true, 1330.0);
    dUnlock.SetMargin(inkMargin(0.0, 0.0, 0.0, 16.0));
    dUnlock.SetTintColor(new HDRColor(0.00, 0.85, 0.85, 1.0));
    dUnlock.SetVisible(false);
    dUnlock.Reparent(detail);
    this.m_detailUnlock = dUnlock;

    // warning line for quests that lock the rest of the game
    let dPoint: ref<inkText> = new inkText();
    dPoint.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    dPoint.SetFontStyle(n"Medium");
    dPoint.SetFontSize(26);
    dPoint.SetFitToContent(true);
    dPoint.SetWrapping(true, 1330.0);
    dPoint.SetMargin(inkMargin(0.0, 0.0, 0.0, 16.0));
    dPoint.SetTintColor(new HDRColor(0.90, 0.35, 0.30, 1.0));
    dPoint.SetVisible(false);
    dPoint.Reparent(detail);
    this.m_detailPoint = dPoint;

    // scrollable detail content (long descriptions won't overflow the panel)
    let dView: ref<inkScrollArea> = new inkScrollArea();
    dView.SetSize(Vector2(1380.0, 760.0));
    dView.SetUseInternalMask(true);
    dView.SetConstrainContentPosition(true);
    dView.Reparent(detail);

    let dContent: ref<inkVerticalPanel> = new inkVerticalPanel();
    dContent.SetName(n"detailContent");
    dContent.Reparent(dView);
    this.m_detailContent = dContent;

    let dDesc: ref<inkText> = new inkText();
    dDesc.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    dDesc.SetFontStyle(n"Medium");
    dDesc.SetFontSize(24);
    dDesc.SetFitToContent(true);
    dDesc.SetWrapping(true, 1330.0);
    dDesc.SetMargin(inkMargin(0.0, 0.0, 0.0, 20.0));
    dDesc.SetTintColor(new HDRColor(0.62, 0.62, 0.64, 1.0));
    dDesc.SetText(loc.GetText("Mod-QuestGuide-Detail-Placeholder"));
    dDesc.Reparent(dContent);
    this.m_detailDesc = dDesc;

    let dObjectives: ref<inkVerticalPanel> = new inkVerticalPanel();
    dObjectives.SetName(n"objectives");
    dObjectives.Reparent(dContent);
    this.m_detailObjectives = dObjectives;

    this.m_selected = -1;
    // filters and search from the last time it was open (saved on the player when closed)
    let player: ref<PlayerPuppet> = GameInstance.GetPlayerSystem(this.GetGame())
      .GetLocalPlayerMainGameObject() as PlayerPuppet;
    if IsDefined(player) && ArraySize(player.m_qgSaveShow) == 4 {
      let si: Int32 = 0;
      while si < 4 {
        this.m_stateShow[si] = player.m_qgSaveShow[si];
        si += 1;
      };
      this.UpdateStateToggles();
      this.m_search.SetText(player.m_qgSaveSearch);
    };
    if IsDefined(player) && ArraySize(player.m_qgSaveOpen) == 6 + QGFixerCount() {
      let so: Int32 = 0;
      while so < 3 {
        this.m_sectionOpen[so] = player.m_qgSaveOpen[so];
        so += 1;
      };
    };
    this.m_quests = QGBuildQuestList(this.GetGame());

    // total progress in place of the "QUESTGUIDE" fluff
    let gDone: Int32 = 0;
    let gi: Int32 = 0;
    while gi < ArraySize(this.m_quests) {
      if Equals(this.m_quests[gi].state, gameJournalEntryState.Succeeded) {
        gDone += 1;
      };
      gi += 1;
    };
    this.m_header.SetFluffRight(IntToString(gDone) + "/" + IntToString(ArraySize(this.m_quests))
      + " " + loc.GetText("Mod-QuestGuide-Progress-Done"));

    this.Rebuild();
    // opens already scrolled to the tracked quest (filter rebuilds don't reset the scroll)
    if this.m_trackedY >= 0.0 {
      this.m_scrollOffset = -MaxF(0.0, this.m_trackedY - 300.0);
      this.ApplyScroll();
    };
  }

  protected func UpdateStateToggles() {
    let loc: ref<LocalizationSystem> = this.QGLoc();
    let i: Int32 = 0;
    while i < ArraySize(this.m_stateToggles) {
      this.m_stateToggles[i].SetText((this.m_stateShow[i] ? "[x] " : "[ ] ")
        + QGStateShowLabel(i, loc));
      this.m_stateToggles[i].SetTintColor(this.m_stateShow[i]
        ? QGStateShowColor(i) : new HDRColor(0.35, 0.35, 0.36, 1.0));
      i += 1;
    };
  }

  // row filter: search + state toggles
  protected func RowVisible(item: QGQuest, needle: String) -> Bool {
    if !Equals(needle, "") && !StrContains(item.search, needle) {
      return false;
    };
    return this.m_stateShow[QGStateToggleIdx(item.state)];
  }

  protected cb func OnSearchInput(widget: wref<inkWidget>) {
    this.Rebuild();
  }

  protected func Rebuild() {
    let loc: ref<LocalizationSystem> = this.QGLoc();
    this.m_listPanel.RemoveAllChildren();
    ArrayClear(this.m_hoverRows);
    ArrayClear(this.m_hoverNames);
    ArrayClear(this.m_hoverQuests);
    ArrayClear(this.m_sectionHeads);
    ArrayClear(this.m_sectionSlots);
    this.m_scrollOffset = 0.0;
    this.m_contentHeight = 0.0;
    this.m_trackedY = -1.0;
    let needle: String = UTF8StrLower(this.m_search.GetText());
    if !Equals(needle, "") {
      this.IndexSearchText();
    };
    this.AddSection(this.m_quests, QGCategory.Main,
      loc.GetText("Mod-QuestGuide-Section-Main"), new HDRColor(1.00, 0.82, 0.00, 1.0), needle,
      0, -1);
    this.AddSection(this.m_quests, QGCategory.PhantomLiberty,
      loc.GetText("Mod-QuestGuide-Section-PhantomLiberty"), new HDRColor(0.75, 0.45, 1.00, 1.0),
      needle, 1, -1);
    this.AddSection(this.m_quests, QGCategory.Ending,
      loc.GetText("Mod-QuestGuide-Section-Ending"), new HDRColor(0.00, 0.85, 0.85, 1.0), needle,
      2, -1);
    this.AddSection(this.m_quests, QGCategory.Cyberpsycho,
      loc.GetText("Mod-QuestGuide-Section-Cyberpsycho"), new HDRColor(0.95, 0.35, 0.55, 1.0),
      needle, 3, -1);
    this.AddSection(this.m_quests, QGCategory.Ncpd,
      loc.GetText("Mod-QuestGuide-Section-Ncpd"), new HDRColor(0.35, 0.65, 1.00, 1.0),
      needle, 4, -1);
    this.AddSection(this.m_quests, QGCategory.Cosmetic,
      loc.GetText("Mod-QuestGuide-Section-Cosmetic"), new HDRColor(0.62, 0.62, 0.64, 1.0), needle,
      5, -1);
    // one section per fixer; an empty one is skipped instead of showing a 0/0 header
    let f: Int32 = 0;
    while f < QGFixerCount() {
      let title: String = Equals(QGFixerName(f), "")
        ? loc.GetText("Mod-QuestGuide-Section-Gigs") : QGFixerName(f);
      this.AddSection(this.m_quests, QGCategory.Gig, title,
        new HDRColor(1.00, 0.55, 0.20, 1.0), needle, 6 + f, f);
      f += 1;
    };
    this.ApplyScroll();
  }

  // description and objectives of every quest, walked once on the first search: doing it in the
  // fetch would pay for the whole journal on each open, even without searching
  protected func IndexSearchText() {
    if this.m_searchIndexed {
      return;
    };
    this.m_searchIndexed = true;
    let jm: ref<JournalManager> = GameInstance.GetJournalManager(this.GetGame());
    let i: Int32 = 0;
    while i < ArraySize(this.m_quests) {
      this.m_quests[i].search += " " + UTF8StrLower(QGQuestText(jm, this.m_quests[i].entry));
      i += 1;
    };
  }

  // fixer < 0 takes the whole category; otherwise only the gigs of that fixer
  protected func AddSection(quests: array<QGQuest>, category: QGCategory,
      title: String, color: HDRColor, needle: String, slot: Int32, fixer: Int32) {
    let loc: ref<LocalizationSystem> = this.QGLoc();

    let total: Int32 = 0;
    let done: Int32 = 0;
    let i: Int32 = 0;
    while i < ArraySize(quests) {
      if Equals(quests[i].category, category) && (fixer < 0 || quests[i].fixer == fixer)
          && (Equals(needle, "") || StrContains(quests[i].search, needle)) {
        total += 1;
        if Equals(quests[i].state, gameJournalEntryState.Succeeded) {
          done += 1;
        };
      };
      i += 1;
    };

    // while searching, collapse is ignored — a result never hides behind a closed section
    if total == 0 && (fixer >= 0 || Equals(category, QGCategory.PhantomLiberty)
        || Equals(category, QGCategory.Cyberpsycho) || Equals(category, QGCategory.Ncpd)) {
      return;
    };
    let open: Bool = this.m_sectionOpen[slot] || !Equals(needle, "");

    let head: ref<inkText> = new inkText();
    head.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    head.SetFontStyle(n"Medium");
    head.SetFontSize(38);
    head.SetFitToContent(true);
    // first section hugs the top; the rest get breathing room
    head.SetMargin(inkMargin(0.0, this.m_contentHeight > 0.0 ? 36.0 : 0.0, 0.0, 16.0));
    head.SetTintColor(color);
    head.SetInteractive(true);
    head.SetText((open ? "- " : "+ ") + title + "  " + IntToString(done) + "/" + IntToString(total));
    head.Reparent(this.m_listPanel);
    ArrayPush(this.m_sectionHeads, head);
    ArrayPush(this.m_sectionSlots, slot);
    this.m_contentHeight += this.m_contentHeight > 0.0 ? 102.0 : 66.0;
    if !open {
      return;
    };

    i = 0;
    while i < ArraySize(quests) {
      if Equals(quests[i].category, category) && (fixer < 0 || quests[i].fixer == fixer)
          && this.RowVisible(quests[i], needle) {
        let row: ref<inkHorizontalPanel> = new inkHorizontalPanel();
        row.SetMargin(inkMargin(24.0, 0.0, 0.0, 10.0));
        row.SetInteractive(true);
        row.Reparent(this.m_listPanel);

        let name: ref<inkText> = new inkText();
        name.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
        name.SetFontStyle(n"Medium");
        name.SetFontSize(32);
        name.SetFitToContent(true);
        name.SetTintColor(i == this.m_selected
          ? new HDRColor(1.0, 1.0, 1.0, 1.0) : QGStateColor(quests[i].state));
        name.SetText(quests[i].title
          + (quests[i].tracked ? ("  " + loc.GetText("Mod-QuestGuide-Quest-TrackedSuffix")) : "")
          + (QGIsPointOfNoReturn(quests[i].entry.GetId())
            ? ("  " + loc.GetText("Mod-QuestGuide-Quest-PointSuffix")) : ""));
        name.Reparent(row);

        // gray state word next to the name (GME-style)
        let stateText: ref<inkText> = new inkText();
        stateText.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
        stateText.SetFontStyle(n"Medium");
        stateText.SetFontSize(26);
        stateText.SetFitToContent(true);
        stateText.SetMargin(inkMargin(28.0, 6.0, 0.0, 0.0));
        stateText.SetTintColor(new HDRColor(0.62, 0.62, 0.64, 1.0));
        stateText.SetText(QGStateWord(quests[i].state, loc));
        stateText.Reparent(row);

        // hovering any row feeds the detail panel
        row.RegisterToCallback(n"OnHoverOver", this, n"OnRowHoverOver");
        row.RegisterToCallback(n"OnHoverOut", this, n"OnRowHoverOut");
        ArrayPush(this.m_hoverRows, row);
        ArrayPush(this.m_hoverNames, name);
        ArrayPush(this.m_hoverQuests, i);
        if quests[i].tracked && this.m_trackedY < 0.0 {
          this.m_trackedY = this.m_contentHeight;
        };
        // raj 32 fitToContent ~42px + bottom margin
        this.m_contentHeight += 52.0;
      };
      i += 1;
    };
  }

  protected cb func OnAttach() {
    super.OnAttach();
    this.RegisterToGlobalInputCallback(n"OnPostOnRelative", this, n"OnQGRelativeInput");
  }

  protected cb func OnDetach() {
    this.UnregisterFromGlobalInputCallback(n"OnPostOnRelative", this, n"OnQGRelativeInput");
    let player: ref<PlayerPuppet> = GameInstance.GetPlayerSystem(this.GetGame())
      .GetLocalPlayerMainGameObject() as PlayerPuppet;
    if IsDefined(player) {
      player.m_qgSaveShow = this.m_stateShow;
      player.m_qgSaveSearch = this.m_search.GetText();
      player.m_qgSaveOpen = this.m_sectionOpen;
    };
    super.OnDetach();
  }

  // mouse wheel scrolls the area under the cursor: list on the left, detail on the right
  protected cb func OnQGRelativeInput(evt: ref<inkPointerEvent>) -> Bool {
    if evt.IsAction(n"mouse_wheel") && NotEquals(evt.GetAxisData(), 0.0) {
      if this.m_overDetail {
        this.m_detailScroll += evt.GetAxisData() * 105.0;
        this.ApplyDetailScroll();
      } else {
        this.m_scrollOffset += evt.GetAxisData() * 105.0;
        this.ApplyScroll();
      };
    };
    return false;
  }

  protected cb func OnDetailHoverOver(evt: ref<inkPointerEvent>) -> Bool {
    this.m_overDetail = true;
    return false;
  }

  protected cb func OnDetailHoverOut(evt: ref<inkPointerEvent>) -> Bool {
    this.m_overDetail = false;
    return false;
  }

  protected cb func OnGlobalReleaseInput(evt: ref<inkPointerEvent>) -> Bool {
    if evt.IsAction(n"mouse_left") && !evt.IsHandled() {
      let target: wref<inkWidget> = evt.GetTarget();
      if IsDefined(target) && Equals(target, this.m_trackBtn) {
        this.TrackSelected();
        return super.OnGlobalReleaseInput(evt);
      };
      let s: Int32 = 0;
      while IsDefined(target) && s < ArraySize(this.m_sectionHeads) {
        if Equals(target, this.m_sectionHeads[s]) {
          this.m_sectionOpen[this.m_sectionSlots[s]] = !this.m_sectionOpen[this.m_sectionSlots[s]];
          let keep: Float = this.m_scrollOffset;
          this.Rebuild();
          this.m_scrollOffset = keep;
          this.ApplyScroll();
          return super.OnGlobalReleaseInput(evt);
        };
        s += 1;
      };
      let t: Int32 = 0;
      while IsDefined(target) && t < ArraySize(this.m_stateToggles) {
        if Equals(target, this.m_stateToggles[t]) {
          this.m_stateShow[t] = !this.m_stateShow[t];
          this.UpdateStateToggles();
          this.Rebuild();
          return super.OnGlobalReleaseInput(evt);
        };
        t += 1;
      };
      let i: Int32 = 0;
      while IsDefined(target) && i < ArraySize(this.m_hoverRows) {
        if Equals(target, this.m_hoverRows[i]) {
          this.SelectQuest(this.m_hoverQuests[i]);
          break;
        };
        i += 1;
      };
    };
    return super.OnGlobalReleaseInput(evt);
  }

  // click selects: name turns white and the right panel shows the info
  protected func SelectQuest(idx: Int32) {
    let j: Int32 = 0;
    while j < ArraySize(this.m_hoverQuests) {
      if this.m_hoverQuests[j] == this.m_selected {
        this.m_hoverNames[j].SetTintColor(QGStateColor(this.m_quests[this.m_selected].state));
      };
      j += 1;
    };
    this.m_selected = idx;
    j = 0;
    while j < ArraySize(this.m_hoverQuests) {
      if this.m_hoverQuests[j] == idx {
        this.m_hoverNames[j].SetTintColor(new HDRColor(1.0, 1.0, 1.0, 1.0));
      };
      j += 1;
    };
    this.ShowDetail(idx);
  }

  protected func TrackSelected() {
    if this.m_selected < 0 || Equals(this.m_quests[this.m_selected].state, gameJournalEntryState.Succeeded) {
      return;
    };
    QGTrackQuest(this.GetGame(), this.m_quests[this.m_selected].entry);
    this.RefreshTracked();
    let keep: Float = this.m_scrollOffset;
    this.Rebuild();
    this.m_scrollOffset = keep;
    this.ApplyScroll();
    this.ShowDetail(this.m_selected);
  }

  protected cb func OnRowHoverOver(evt: ref<inkPointerEvent>) -> Bool {
    let target: wref<inkWidget> = evt.GetCurrentTarget();
    let i: Int32 = 0;
    while i < ArraySize(this.m_hoverRows) {
      if Equals(target, this.m_hoverRows[i]) {
        this.m_hoverNames[i].SetTintColor(new HDRColor(1.0, 1.0, 1.0, 1.0));
        break;
      };
      i += 1;
    };
    return false;
  }

  protected cb func OnRowHoverOut(evt: ref<inkPointerEvent>) -> Bool {
    let target: wref<inkWidget> = evt.GetCurrentTarget();
    let i: Int32 = 0;
    while i < ArraySize(this.m_hoverRows) {
      if Equals(target, this.m_hoverRows[i]) {
        // the selected one stays white
        if this.m_hoverQuests[i] != this.m_selected {
          this.m_hoverNames[i].SetTintColor(QGStateColor(this.m_quests[this.m_hoverQuests[i]].state));
        };
        break;
      };
      i += 1;
    };
    return false;
  }

  // detail: description (JournalQuestDescription) + objectives (quest -> phases -> objectives);
  // inactive is left out to avoid spoiling a future objective
  protected func ShowDetail(idx: Int32) {
    let loc: ref<LocalizationSystem> = this.QGLoc();
    let jm: ref<JournalManager> = GameInstance.GetJournalManager(this.GetGame());
    let item: QGQuest = this.m_quests[idx];
    this.m_detailTitle.SetTintColor(QGStateColor(item.state));
    this.m_detailTitle.SetText(item.title);
    this.m_detailObjectives.RemoveAllChildren();
    this.m_detailScroll = 0.0;
    this.m_detailHeight = 0.0;

    let reason: String = Equals(item.category, QGCategory.Ending)
      ? QGEndingReason(item.entry.GetId(), loc) : "";
    if Equals(reason, "") {
      this.m_detailUnlock.SetVisible(false);
    } else {
      this.m_detailUnlock.SetVisible(true);
      this.m_detailUnlock.SetText(loc.GetText("Mod-QuestGuide-Detail-Unlocks") + " " + reason);
    };

    let isPoint: Bool = QGIsPointOfNoReturn(item.entry.GetId());
    this.m_detailPoint.SetVisible(isPoint);
    if isPoint {
      this.m_detailPoint.SetText(loc.GetText("Mod-QuestGuide-Detail-PointOfNoReturn"));
    };

    if Equals(item.state, gameJournalEntryState.Succeeded) {
      this.m_trackBtn.SetVisible(false);
    } else {
      this.m_trackBtn.SetVisible(true);
      if item.tracked {
        this.m_trackBtn.SetText(loc.GetText("Mod-QuestGuide-Track-Tracked"));
        this.m_trackBtn.SetTintColor(new HDRColor(0.30, 0.85, 0.35, 1.0));
      } else {
        this.m_trackBtn.SetText(loc.GetText("Mod-QuestGuide-Track-Action"));
        this.m_trackBtn.SetTintColor(new HDRColor(1.00, 0.82, 0.00, 1.0));
      };
    };

    let filter: JournalRequestStateFilter;
    filter.active = true;
    filter.succeeded = true;
    filter.failed = true;
    let children: array<wref<JournalEntry>>;
    jm.GetChildren(item.entry, filter, children);

    let descFilter: JournalRequestStateFilter;
    descFilter.active = true;
    descFilter.inactive = true;
    descFilter.succeeded = true;
    descFilter.failed = true;
    let descChildren: array<wref<JournalEntry>>;
    jm.GetChildren(item.entry, descFilter, descChildren);
    let desc: String = "";
    let di: Int32 = 0;
    while di < ArraySize(descChildren) {
      let dEntry: wref<JournalQuestDescription> = descChildren[di] as JournalQuestDescription;
      if IsDefined(dEntry) && Equals(desc, "") {
        desc = QGLocText(dEntry.GetDescription());
      };
      di += 1;
    };

    let i: Int32 = 0;
    while i < ArraySize(children) {
      let phase: wref<JournalQuestPhase> = children[i] as JournalQuestPhase;
      if IsDefined(phase) {
        let objs: array<wref<JournalEntry>>;
        jm.GetChildren(phase, filter, objs);
        let j: Int32 = 0;
        while j < ArraySize(objs) {
          this.AddObjectiveRow(jm, objs[j] as JournalQuestObjective);
          j += 1;
        };
      };
      this.AddObjectiveRow(jm, children[i] as JournalQuestObjective);
      i += 1;
    };
    let descText: String = Equals(desc, "")
      ? loc.GetText("Mod-QuestGuide-Detail-NoDescription") : desc;
    this.m_detailDesc.SetText(descText);
    this.m_detailHeight += Cast<Float>(QGEstLines(descText, 80)) * 32.0 + 20.0;
    this.ApplyDetailScroll();
  }

  protected func AddObjectiveRow(jm: ref<JournalManager>, obj: wref<JournalQuestObjective>) {
    if !IsDefined(obj) {
      return;
    };
    let state: gameJournalEntryState = jm.GetEntryState(obj);
    let text: String = QGStatePrefix(state) + QGLocText(obj.GetDescription());
    if obj.HasCounter() {
      text += " (" + IntToString(jm.GetObjectiveCurrentCounter(obj))
        + "/" + IntToString(jm.GetObjectiveTotalCounter(obj)) + ")";
    };
    if jm.GetIsObjectiveOptional(obj) {
      text += " " + this.QGLoc().GetText("Mod-QuestGuide-Objective-Optional");
    };
    let row: ref<inkText> = new inkText();
    row.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    row.SetFontStyle(n"Medium");
    row.SetFontSize(24);
    row.SetFitToContent(true);
    row.SetWrapping(true, 1330.0);
    row.SetMargin(inkMargin(0.0, 0.0, 0.0, 8.0));
    row.SetTintColor(QGStateColor(state));
    row.SetText(text);
    row.Reparent(this.m_detailObjectives);
    this.m_detailHeight += Cast<Float>(QGEstLines(text, 80)) * 32.0 + 8.0;
  }

  // tracked state comes from the fetch; after TrackEntry only the flag changes, no refetch
  protected func RefreshTracked() {
    let jm: ref<JournalManager> = GameInstance.GetJournalManager(this.GetGame());
    let tracked: wref<JournalEntry> = jm.GetTrackedEntry();
    let i: Int32 = 0;
    while i < ArraySize(this.m_quests) {
      this.m_quests[i].tracked = IsDefined(tracked) && tracked == this.m_quests[i].entry;
      i += 1;
    };
  }

  protected func ApplyScroll() {
    let viewportHeight: Float = 900.0;
    if this.m_scrollOffset > 0.0 {
      this.m_scrollOffset = 0.0;
    };
    let maxScroll: Float = MaxF(0.0, this.m_contentHeight - viewportHeight);
    this.m_scrollOffset = MaxF(-maxScroll, this.m_scrollOffset);
    this.m_scrollContent.SetTranslation(new Vector2(0.0, this.m_scrollOffset));
  }

  protected func ApplyDetailScroll() {
    if this.m_detailScroll > 0.0 {
      this.m_detailScroll = 0.0;
    };
    let maxScroll: Float = MaxF(0.0, this.m_detailHeight - 760.0);
    this.m_detailScroll = MaxF(-maxScroll, this.m_detailScroll);
    this.m_detailContent.SetTranslation(new Vector2(0.0, this.m_detailScroll));
  }

  public static func Show(player: ref<PlayerPuppet>) -> ref<QuestGuidePopup> {
    let popup: ref<QuestGuidePopup> = new QuestGuidePopup();
    GameInstance.GetUISystem(player.GetGame()).QueueEvent(ShowCustomPopupEvent.Create(popup));
    return popup;
  }
}

// Hotkey: F2 by default, picked in Mod Settings. Input/Key is raw input, so a letter key would
// also fire while typing in any text field (reported on Nexus); F keys never reach a text input

@addField(PlayerPuppet)
let m_qgPopup: ref<QuestGuidePopup>;

@addField(PlayerPuppet)
let m_qgInBlockedMenu: Bool;

// filters/search persist across openings (popup is recreated on every U)
@addField(PlayerPuppet)
let m_qgSaveShow: array<Bool>;

@addField(PlayerPuppet)
let m_qgSaveSearch: String;

@addField(PlayerPuppet)
let m_qgSaveOpen: array<Bool>;

// opening over the pause/death menu locks input (reported on Nexus); hub/inventory are fine.
// Background covers the whole ESC chain (pause -> save -> settings); the pause controller
// itself gets swapped in submenus and the flag would reset while typing a save name
@wrapMethod(PauseMenuBackgroundGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_qgInBlockedMenu = true;
  };
  return wrappedMethod();
}

@wrapMethod(PauseMenuBackgroundGameController)
protected cb func OnUninitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_qgInBlockedMenu = false;
  };
  return wrappedMethod();
}

@wrapMethod(DeathMenuGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_qgInBlockedMenu = true;
  };
  return wrappedMethod();
}

@wrapMethod(DeathMenuGameController)
protected cb func OnUninitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_qgInBlockedMenu = false;
  };
  return wrappedMethod();
}

@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  let result: Bool = wrappedMethod();
  // Session: goes away with the session, otherwise an orphaned callback fires in the main menu
  GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnQGKeyInput")
    .SetLifetime(CallbackLifetime.Session);
  return result;
}

@wrapMethod(PlayerPuppet)
protected cb func OnDetach() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnQGKeyInput");
  return wrappedMethod();
}

@addMethod(PlayerPuppet)
protected cb func OnQGKeyInput(event: ref<KeyInputEvent>) {
  if !Equals(event.GetAction(), EInputAction.IACT_Press)
    || !Equals(event.GetKey(), QuestGuideSettings.KeyOf(this.GetGame())) {
    return;
  };
  if IsDefined(this.m_qgPopup) && this.m_qgPopup.QGIsOpen() {
    this.m_qgPopup.Close();
    this.m_qgPopup = null;
    return;
  };
  // only blocks opening: pause/death menu (softlock) and pre-game (main menu)
  if this.m_qgInBlockedMenu || GameInstance.GetSystemRequestsHandler().IsPreGame() {
    return;
  };
  this.m_qgPopup = null;
  this.m_qgPopup = QuestGuidePopup.Show(this);
}
