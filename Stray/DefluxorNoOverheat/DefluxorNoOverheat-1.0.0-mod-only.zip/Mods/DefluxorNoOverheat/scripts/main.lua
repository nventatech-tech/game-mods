-- DefluxorNoOverheat: zera HeatIncreaseSpeed do B-12 (CDO + instancias) a cada 5s.
-- Sem hook de construcao (crashava no Stray); loop leve cobre load de save e respawn.
local CDO_PATH = "/Game/Character/Drone/BP_Drone.Default__BP_Drone_C"

local function patch(obj)
    obj.HeatIncreaseSpeed = 0.0
end

local function apply()
    local cdo = StaticFindObject(CDO_PATH)
    if cdo and cdo:IsValid() then pcall(patch, cdo) end
    local drones = FindAllOf("BP_Drone_C")
    if drones then
        for _, d in ipairs(drones) do
            if d and d:IsValid() then pcall(patch, d) end
        end
    end
end

LoopAsync(5000, function()
    pcall(apply)
    return false
end)

print("[DefluxorNoOverheat] ativo: HeatIncreaseSpeed = 0\n")
