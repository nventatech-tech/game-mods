extends Node

const MOD_DIR = "opaaaaaaaaaaaa-ShopWishlist/"
const LOG_NAME = "opaaaaaaaaaaaa-ShopWishlist"
const SAVE_PATH = "user://shopwishlist.json"

const COLORS = {
	"Yellow": Color(1.0, 0.85, 0.2),
	"Green": Color(0.35, 1.0, 0.35),
	"Cyan": Color(0.3, 0.9, 1.0),
	"Red": Color(1.0, 0.3, 0.3),
	"White": Color(1.0, 1.0, 1.0),
}
const BUTTONS = {
	"R3 (right stick)": JOY_R3,
	"L3 (left stick)": JOY_L3,
	"Select/Back": JOY_SELECT,
}

var wishlist: = {}
var highlight_color: Color = COLORS["Yellow"]
var controller_button: int = JOY_R3
var _color_name: String = "Yellow"
var _button_name: String = "R3 (right stick)"


func _init() -> void :
	ModLoaderLog.info("Init", LOG_NAME)
	var dir = ModLoaderMod.get_unpacked_dir() + MOD_DIR
	ModLoaderMod.install_script_extension(dir + "extensions/ui/menus/shop/shop_item.gd")
	_load_wishlist()


func _ready() -> void :
	_load_config()
	call_deferred("_connect_mod_options")


func has_item(item_id: String) -> bool:
	return wishlist.has(item_id)


func toggle_item(item_id: String) -> void :
	if wishlist.has(item_id):
		wishlist.erase(item_id)
	else:
		wishlist[item_id] = true
	_save_wishlist()


func _load_wishlist() -> void :
	var f = File.new()
	if not f.file_exists(SAVE_PATH):
		return
	if f.open(SAVE_PATH, File.READ) != OK:
		return
	var parsed = parse_json(f.get_as_text())
	f.close()
	if parsed is Array:
		for id in parsed:
			if id is String:
				wishlist[id] = true


func _save_wishlist() -> void :
	var f = File.new()
	if f.open(SAVE_PATH, File.WRITE) == OK:
		f.store_string(to_json(wishlist.keys()))
		f.close()


func _load_config() -> void :
	var config = ModLoaderConfig.get_current_config(LOG_NAME)
	if config == null:
		config = ModLoaderConfig.get_default_config(LOG_NAME)
	if config == null:
		return
	_apply_setting("highlight_color", config.data.get("highlight_color", _color_name))
	_apply_setting("controller_button", config.data.get("controller_button", _button_name))


func _connect_mod_options() -> void :
	var iface = get_node_or_null("/root/ModLoader/dami-ModOptions/ModsConfigInterface")
	if iface != null and not iface.is_connected("setting_changed", self, "_on_setting_changed"):
		iface.connect("setting_changed", self, "_on_setting_changed")


func _on_setting_changed(setting_name: String, value, mod_name: String) -> void :
	if mod_name != LOG_NAME:
		return
	if setting_name == "clear_wishlist":
		if value:
			wishlist.clear()
			_save_wishlist()
			_save_config()
		return
	_apply_setting(setting_name, value)
	_save_config()


func _apply_setting(setting_name: String, value) -> void :
	match setting_name:
		"highlight_color":
			_color_name = str(value)
			highlight_color = COLORS.get(_color_name, COLORS["Yellow"])
		"controller_button":
			_button_name = str(value)
			controller_button = BUTTONS.get(_button_name, JOY_R3)


# clear_wishlist always saved as false so the clear action never persists
func _save_config() -> void :
	var data: = {
		"highlight_color": _color_name,
		"controller_button": _button_name,
		"clear_wishlist": false
	}
	var config = ModLoaderConfig.get_config(LOG_NAME, "current")
	if config == null:
		config = ModLoaderConfig.create_config(LOG_NAME, "current", data)
	else:
		config.data = data
		config = ModLoaderConfig.update_config(config)
	if config != null:
		ModLoaderConfig.set_current_config(config)
