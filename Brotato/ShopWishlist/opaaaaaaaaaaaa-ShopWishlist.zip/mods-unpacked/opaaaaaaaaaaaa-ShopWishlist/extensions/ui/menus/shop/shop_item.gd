extends "res://ui/menus/shop/shop_item.gd"


onready var sw_store = get_node_or_null("/root/ModLoader/opaaaaaaaaaaaa-ShopWishlist")


func _input(event) -> void :
	if sw_store == null or item_data == null or not active or not is_visible_in_tree():
		return
	if event is InputEventMouseButton and event.button_index == BUTTON_RIGHT and event.pressed:
		# stretch 2d scales the canvas; raw event.global_position is window-space
		if get_global_rect().has_point(get_global_mouse_position()):
			sw_toggle()
	elif event is InputEventJoypadButton and event.pressed and event.button_index == sw_store.controller_button:
		if _button.has_focus():
			sw_toggle()


func sw_toggle() -> void :
	sw_store.toggle_item(item_data.my_id)
	_set_panel_lock_style()


# base rebuilds the stylebox override on every set/lock change, so the
# wishlist border is re-applied here on top of whatever it produced
func _set_panel_lock_style() -> void :
	._set_panel_lock_style()
	if sw_store == null or item_data == null or not sw_store.has_item(item_data.my_id):
		return
	var panel = _item_description.icon_panel if RunData.is_coop_run else _panel
	var stylebox = panel.get_stylebox("panel")
	if stylebox is StyleBoxFlat:
		stylebox.set_border_width_all(4)
		stylebox.border_color = sw_store.highlight_color
